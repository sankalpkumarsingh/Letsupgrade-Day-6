class bankaccount():
    def __init__(self):
        self.ownername="sankalp"
        self.Balance=0
    def deposit(self):
        Amount = float(input("\nEnter the amount to be deposited:"))
        self.Balance += Amount
        print("\nAmount deposited is",Amount)
    def withdraw(self):
        Amount  = float(input("\nEnter the amount to be withdrawn"))
        if self.Balance >= Amount:
           self.Balance -= Amount
           print("\nYou have withdrawn amount",Amount)
        else:
         print("\n insufficent funds")
print("\nWelcome to bank acount program")
BA = bankaccount()

print("\nAcccount holde name is",BA.ownername)

print("\nInitial bank balance",BA.Balance)
BA.deposit();
BA.withdraw();
print("\nAvaialble balance is",BA.Balance)
        
