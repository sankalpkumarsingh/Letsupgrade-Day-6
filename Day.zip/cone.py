import math
pi = math.pi
class cone:
     def __init__(self,r,h):
         self.r=r
         self.h= h
     def volume(self):
        result= (1/3)*pi*self.r*self.r*self.h
        print("\n volume of cone is:",result)
     def surfacearea(self):
        result = pi*self.r*self.h+pi*self.r*self.r
        print("\nsurface area of cone is",result)
rad = float(input("\nenter radius of cone"))
hei = float(input("\nenter height of cone")) 
c= cone(rad,hei)
c.volume()
c.surfacearea()